//=============================================================================
// Plugin for RPG Maker MZ
// Extra2KLetters.js
//=============================================================================

/*:
 * @target MZ
 * @plugindesc Enables to display RPG Maker 2000's extended letters
 * @author Sasuke KANNAZUKI
 *
 * @requiredAssets img/system/extend2000
 *
 * @help This plugin does not provide plugin commands.
 * This plugin runs under RPG Maker MZ.
 * This plugin enables to display RPG Maker 2000 like extended letters.
 *
 * [At first you have to do]
 * put extend2000.png at /img/system/ .
 *
 * [Summary]
 * To display RM2000 letters, write down following description.
 * $A, $B, $C, ... and $Z   : letters equips and zodiac
 * $a, $b, $c, ... and $z   : letters face, card suits, and so on.
 * This character after $ checks whether it's capital or not.
 *
 * [License]
 * this plugin is released under MIT license.
 * http://opensource.org/licenses/mit-license.php
 */

/*:ja
 * @target MZ
 * @plugindesc RPGツクール2000の外字を表示可能にします。
 * @author 神無月サスケ
 *
 * @requiredAssets img/system/extend2000
 *
 * @help このプラグインには、プラグインコマンドはありません。
 * このプラグインは、RPGツクールMZに対応しています。
 * このプラグインは、RPGツクール2000の外字を表示可能にします。
 *
 * ■最初にすべきこと
 * 添付のextend2000.png を img/system/ フォルダに置いて下さい。
 *
 * ■概要
 * ツクール2000の外字を表示するには、以下の書式にします。
 * $A, $B, $C, ... and $Z   : 主に装備や星占いの記号を表示します。
 * $a, $b, $c, ... and $z   : 顔やトランプのスートや矢印などを表示します。
 * 上記のように、$に続くアルファベットは大文字と小文字を区別します。
 *
 * ■ライセンス表記
 * このプラグインは MIT ライセンスで配布されます。
 * ご自由にお使いください。
 * http://opensource.org/licenses/mit-license.php
 */

(() => {
  //
  // process $ the character
  //
  const _Window_Base_convertEscapeCharacters =
    Window_Base.prototype.convertEscapeCharacters;
  Window_Base.prototype.convertEscapeCharacters = function(text) {
    text = _Window_Base_convertEscapeCharacters.call(this, text);
    // match $ except \$
    text = text.replace(/(?<!\x1b)\$(?!\n)/g, '\x1b2KG');
    return text;
  };

  const _Window_Base_obtainEscapeCode = Window_Base.prototype.obtainEscapeCode;
  Window_Base.prototype.obtainEscapeCode = function(textState) {
    // check 2KG (original character : $)
    const regExp = /^2KG/g;
    const arr = regExp.exec(textState.text.slice(textState.index));
    if (arr) {
      textState.index += arr[0].length;
      return arr[0];
    }
    return _Window_Base_obtainEscapeCode.call(this, textState);
  };

  const obtain2kLetter = textState => {
    const regExp = /^[A-Za-z]/;
    const arr = regExp.exec(textState.text.slice(textState.index));
    textState.index++;
    if (!arr) {
      return '$' + textState.text.slice(textState.index - 1)[0];
    }
    return arr[0];
  };

  const _Window_Base_processEscapeCharacter =
    Window_Base.prototype.processEscapeCharacter;
  Window_Base.prototype.processEscapeCharacter = function(code, textState) {
    switch (code) {
    case '2KG':
      this.process2KG(obtain2kLetter(textState), textState);
      break;
    }
    _Window_Base_processEscapeCharacter.call(this, code, textState);
  };

  //
  // Display 2000 Extended Character
  //
  Window_Base.prototype.process2KG = function(letter, textState) {
    if ((/^\$./).exec(letter)) {
      textState.buffer += letter;
      return;
    }
    this.draw2KExtended(letter, textState.x, textState.y);
    textState.x += this.contents.fontSize + 8;
  };

  const _Window_Base_initialize = Window_Base.prototype.initialize;
  Window_Base.prototype.initialize = function(rect) {
    _Window_Base_initialize.call(this, rect);
    // preload
    ImageManager.loadSystem("extend2000");
  };

  Window_Base.prototype.fontsizeOf2K = function() {
    return 16;
  };

  Window_Base.prototype.draw2KExtended = function(letter, x, y) {
    const bitmap = ImageManager.loadSystem("extend2000");
    // 'A's code is 65, 'a's code is 97.
    const letterCode = letter.charCodeAt(0);
    const code = letterCode >= 97 ? letterCode - 97 : letterCode - 65;
    const xPos = code.mod(18);
    const yPos = Math.floor(code / 18) + (letterCode >= 97 ? 2 : 0);
    const sFS = this.fontsizeOf2K();
    const sx = xPos * sFS;
    const sy = yPos * sFS;
    const dFS = this.contents.fontSize + 8;
    this.contents.blt(bitmap, sx, sy, sFS, sFS, x, y, dFS, dFS);
  };

})();
