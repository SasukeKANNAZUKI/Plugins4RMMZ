DeadMemberToCoffin.js 2017/06/20 Sasuke KANNAZUKI

[At first you have to do]
- Move attached image '$CoffinVXAce.png' to img/character folder.
- Then, put the plugin at js/plugins and import to your project.

[Important Notice]
- the coffin character is the resized image of RPG Maker VX Ace.
  So, it's no problem if you have the account of the RPG Maker VX Ace.
  If you don't have the account of it, never use this material to your project.

Thank you.